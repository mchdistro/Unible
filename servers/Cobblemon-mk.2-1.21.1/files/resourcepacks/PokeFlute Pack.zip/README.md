# Josh's Poké Flute Pack

A resource pack for Cobblemon that replaces Goat Horns with Poké Flutes.
As well as retexturing elements from other mods to better fit the theme of Cobblemon
