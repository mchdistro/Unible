Thank you for downloading! I hope you enjoy :]
To install, copy this folder into your resourcepacks folder and your world's datapacks folder

Special thanks to Frank The Farmer for helping test the pack and auraofmegalucario991 for fixing up the posers for 1.6

Mega Lucario can be obtained by giving Lucario a diamond and is just cosmetic (For now!)